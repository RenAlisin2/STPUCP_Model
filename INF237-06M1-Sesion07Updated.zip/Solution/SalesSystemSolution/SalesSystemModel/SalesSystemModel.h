#pragma once

using namespace System;

namespace SalesSystemModel {
	public ref class Class1
	{
		// TODO: Agregue aquí los métodos de esta clase.
	};
}
