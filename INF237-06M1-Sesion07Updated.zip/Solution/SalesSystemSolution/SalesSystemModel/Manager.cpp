/**
 * Project Restaurant Sales Systen
 * @author Johan Baldeón
 */
#include "pch.h"

#include "Manager.h"

/**
 * Manager implementation
 */
