/**
 * Project Restaurant Sales Systen
 * @author Johan Baldeón
 */
#pragma once

#ifndef _DELIVER_H
#define _DELIVER_H

using namespace System;

namespace SalesSystemModel {
    public ref class Deliver {
    };
}

#endif //_DELIVER_H