/**
 * Project Restaurant Sales Systen
 * @author Johan Baldeón
 */
#include "pch.h"

#include "Sale.h"

/**
 * Sale implementation
 */
