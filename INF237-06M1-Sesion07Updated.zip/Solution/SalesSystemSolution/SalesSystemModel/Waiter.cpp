/**
 * Project Restaurant Sales Systen
 * @author Johan Baldeón
 */
#include "pch.h"

#include "Waiter.h"

/**
 * Waiter implementation
 */
