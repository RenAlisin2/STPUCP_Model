/**
 * Project Restaurant Sales Systen
 * @author Johan Baldeón
 */
#include "pch.h"

#include "Ingredient.h"

/**
 * Ingredient implementation
 */
