/**
 * Project Restaurant Sales Systen
 * @author Johan Baldeón
 */
#include "pch.h"

#include "DishIngredient.h"

/**
 * DishIngredient implementation
 */
