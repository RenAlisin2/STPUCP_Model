/**
 * Project Restaurant Sales Systen
 * @author Johan Baldeón
 */
#pragma once

#ifndef _CHATSYSTEM_H
#define _CHATSYSTEM_H

using namespace System;

namespace SalesSystemModel {
    public ref class ChatSystem {
    };
}

#endif //_CHATSYSTEM_H